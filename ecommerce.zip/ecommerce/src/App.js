import React from 'react'
import Product from './components/Product'

const App = () => {
  return (
    <div>
      <Product/>
    </div>
  )
}

export default App
