import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import Header from './components/header';
import HomePage from './components/home';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import Profile from './components/profile';
import Post from './components/post';


function App() {
  return (
    <>
      <Header />
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/profile/:id" element={<Profile />} />
          <Route path="/post/:id" element={<Post />} />
        </Routes>
      </BrowserRouter>


    </>
  );
}

export default App;
