import axios from "axios";
import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import Card from 'react-bootstrap/Card';
import { useNavigate } from "react-router-dom";

const Profile = () => {

    const navigate = useNavigate()

    const [data, setData] = useState([])
    const [postData, setPostData] = useState([])

    const { id } = useParams()

    useEffect(() => {
        axios.get(`https://jsonplaceholder.typicode.com/users/${id}`).then((res) => {
            setData(res.data)
        })

        axios.get(`https://jsonplaceholder.typicode.com/posts?userId=${id}`).then((res) => {
            setPostData(res.data)
        })

    }, [])

    

    console.log(data)
    console.log(postData)

    return (
        <>
            <div className="profile-main-page">
                <Card className="profile-card" style={{ width: '15rem' }}>
                    <Card.Img variant="top" src="https://avatars.dicebear.com/api/avataaars/john.svg" />
                    <Card.Body>
                        <Card.Title className="profile-card-title">{data.name}</Card.Title>
                        <Card.Text className="card-text-profile">
                            <div className="attri-div">
                                <span className="attribute">Email</span>
                                <span className="attri-value">{data.email}</span>
                            </div>
                            <div>
                                <span className="attribute">Website</span>
                                <span className="attri-value">{data.website}</span>
                            </div>
                        </Card.Text>
                    </Card.Body>
                </Card>

                    {
                        postData.map((post, index) => {
                            let likes =Math.floor( Math.random() * 10 * 5 + 1)
                            function getIndex(){
                                navigate("/post")
                            }
                            return (
                                <>
                                    <div className="post-details">
                                        <div onClick={getIndex} className="post-title-div">{post.title}</div>
                                        <div className="post-date-div"></div>
                                        <div className="post-likes-div">Likes : {likes}</div>
                                    </div>

                                </>
                            )
                        })
                    }
            </div>
        </>
    )
}

export default Profile;