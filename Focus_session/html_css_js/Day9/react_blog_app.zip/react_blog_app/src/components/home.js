import axios from "axios";
import { useState, useEffect } from "react";
import Button from 'react-bootstrap/Button';
import Card from 'react-bootstrap/Card';
import { useNavigate } from "react-router-dom";
import Profile from "./profile";

const HomePage = () => {

    const navigate = useNavigate()

    const [data, setData] = useState([])

    useEffect(() => {
        axios.get("https://jsonplaceholder.typicode.com/users").then(res => {
            setData(res.data)
        })
    }, [])


    return (
        <>
            <div className="main-page">
                {
                    data.map((user, index) => {

                        let myId = user.id
                        function handleClick() {
                            navigate(`/profile/${myId}`);
                        }

                        return (
                            <>
                                <Card className="card-div" style={{ width: '15rem' }}>
                                    <Card.Img variant="top" src="https://avatars.dicebear.com/api/bottts/:seed.svg" />
                                    <Card.Body>
                                        <Card.Title>{user.name}</Card.Title>
                                        <Button onClick={handleClick} variant="primary">Click to view profile</Button>
                                    </Card.Body>
                                </Card>
                                
                            </>
                        )
                    })
                }
            </div>

        </>
    )
}

export default HomePage;