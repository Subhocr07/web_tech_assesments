import { useState } from 'react';
import './App.css';
import {BiSun} from "react-icons/bi"
import {MdNightlight} from "react-icons/md"


function App() {

  const [toggle, setToggle] = useState(false)
  const [icon, setIcon] = useState(<BiSun style={{color:"#fff"}}/>)
  const [bgColor, setBgColor] = useState("#dcdcdc")
  const [text, setText] = useState("Light")
  const [textColor, setTextColor] = useState("black")
  const [sliderBg, setSliderBg] = useState("#5092b6")


  function handleChange(){
    setToggle(!toggle)
    if(toggle === false){
      setBgColor("#2b2b2d")
      setText("Dark")
      setTextColor("#fff")
      setSliderBg("#10153d")
      setIcon(<MdNightlight style={{color:"#fff"}}/>)
    }
    else{
      setBgColor("#dcdcdc")
      setText("Light")
      setTextColor("black")
      setSliderBg("#5092b6")
      setIcon(<BiSun style={{color:"#fff"}}/>)
    }
  }

  return (
    <>
      <div className='main-div' style={{backgroundColor:bgColor}}>
        <label className="switch">
          <input  className='myCheck' type="checkbox" onChange={handleChange}/>
          <span className="slider round" style={{backgroundColor:sliderBg}}>
            {icon}
          </span>
        </label>
        <div className='text-div' style={{color:textColor}}>
          Its {text} theme!!!
        </div>
      </div>
    </>
  );
}

export default App;
