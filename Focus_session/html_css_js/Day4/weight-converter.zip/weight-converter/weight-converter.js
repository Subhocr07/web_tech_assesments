// var pounds=document.getElementById("pounds")
// var grams=document.getElementById("grams")
// var kilograms=document.getElementById("kilograms")
// var ounces=document.getElementById("ounces")
// var demo=document.getElementById("demo")

// function convert(){
//     if(pounds.value==""){
//     demo.innerText="please enter a valid input"

// }else{
//     grams.innerHTML=(pounds.value*453.6).toFixed(2)+" g"
//     kilograms.innerHTML=(pounds.value*0.45).toFixed(2)+" Kg"
//     ounces.innerHTML=(pounds.value*16).toFixed(2)+" O"
//     demo.innerText=""
// }
// }