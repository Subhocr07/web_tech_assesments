let demost=document.getElementById("demost")
let demosi=document.getElementById("demosi")
for(let i=1;i<10;i++){
var mytimeout=setTimeout(()=>{
    // console.log(i)
    demost.innerText +=" "+i
},i*1000)
}

// var mytimeout=setTimeout(()=>{
//     demost.innerText="something executed after 3 sec"
// },3000)

let i=1
var myinterval=setInterval(()=>{
        // console.log(i=i+1)
        demosi.innerText +=" "+i
        i=i+1
    },1000)

function ct(){
    clearTimeout(mytimeout)
}
function ci(){
    clearInterval(myinterval)
}
