import React, {useState} from 'react'
import "./Temp.css"
const Temp = () => {
    const [temp, setTemp] = useState("0")
    const [tempColor, setTempColor] = useState("cold")

const incTemp=() =>{
    const increasingTemp = parseInt(temp + 1)
    if(increasingTemp>=15){
        setTempColor("lesshot")
    }
    if(increasingTemp>=25 && increasingTemp<35){
        setTempColor("hot")
    }
    if(increasingTemp>=35 && increasingTemp<50){
        setTempColor("morehot")
    }
    if(increasingTemp>=50){
        setTempColor("hotest")
    }

   setTemp(increasingTemp)
} 
const dscTemp=() =>{
    const decreasingTemp = parseInt(temp - 1)
    if(decreasingTemp>=15){
        setTempColor("lesshot")
    }
    if(decreasingTemp>=25 && decreasingTemp<35){
        setTempColor("hot")
    }
    if(decreasingTemp>=35 && decreasingTemp<50){
        setTempColor("morehot")
    }
    if(decreasingTemp>=50){
        setTempColor("hotest")
    }

   setTemp(decreasingTemp)
} 


    return (
        <div class="container" >

            <div class={`round ${tempColor}`} >
                <h1 id="num">{temp}°C</h1>
            </div>

            <div className='buttons'>
                <div className="btnm" onClick={dscTemp}>-</div>
                <div className="btnm" onClick={incTemp} >+</div>
            </div>
            
        </div>
    )
}

export default Temp
