import "./webpage.css"
// const Webpage=()=>{
// const Webpage=function(){
function Webpage(){
    return(
        <div id="container">
        <div className="main">
            <header>
                <h4>ARCH BURO <sup>1/2</sup></h4>
                <div className="contactinfo">
                    <ul>
                <li>hello@archburo.com</li>
                <li>+1 663876748363</li>
                </ul>
                <ul>
                    <li id="bold-li">PROJECTS</li>
                    <li>ABOUT</li>
                    <li>COMPANY</li>
                </ul>
                </div>
            </header>
            <nav>
                <h3>KAGE NORE.</h3>
                <div className="info">
                <ul>
                <li>ARCHITECTURE</li>
                <li>2020</li>
                </ul>
                <ul>
                <li>ANOTONY M.</li>
                <li>SANA G.</li>
                </ul>
                </div>
            </nav>
            <section>
                <div className="main-img">
                <img className="mainimg" src="https://images.unsplash.com/photo-1527330534864-2982f91c776d?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8MTF8fGh1dCUyMG9uJTIwdG9wJTIwb2YlMjBob3VzZXxlbnwwfHwwfHw%3D&auto=format&fit=crop&w=500&q=60" alt="img"/>
                </div>
                <div className="sub-img">
                    <img className="subimg" src="https://images.unsplash.com/photo-1588880331179-bc9b93a8cb5e?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8MTB8fHZzaGFwZSUyMG9uJTIwdG9wJTIwb2YlMjBob3VzZXxlbnwwfHwwfHw%3D&auto=format&fit=crop&w=500&q=60" alt="subimg"/>
                    <p>AS CLAIMED BY THE BELIEF.
                        NOT ONLY SIMPLE BUT
                        ELEGANT GEOMETRIC SHAPES
                        WERE INVENTED BASED ON 
                        THE DELIBERATE PURPOSE OF 
                        A BUILDING OR AN OBJECT 
                    </p>
                </div>
            </section>
        
        </div>
        </div>
    )
}

export default Webpage