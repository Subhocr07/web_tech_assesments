
// import './App.css';
// import Carausel from './components/carousel/Carausel';
// import Temp from './components/temp/Temp';
import Webpage from './components/webpage/webpage';


function App() {
  return (
    <div className="App">
      {/* <Carausel/> */}
      {/* <Temp/> */}
      <Webpage/>
      
    </div>
  );
}

export default App;
