import React from 'react'
import { useState, useEffect } from "react";
import "./form.css"

const Form = () => {
  const initialValues = { name: "", age: "", gender: "" ,occupation:"",iscool:false};
  const [formValues, setFormValues] = useState(initialValues);
  
  const handleChange = (e) => {
    const { name, value,type,checked } = e.target;
    setFormValues((State)=>({
        ...State, [name]:type==='checkbox'?checked : value 
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log(formValues)
    
  };
  return (
    <div className="container">
        <pre>{JSON.stringify(formValues, undefined, 2)}</pre>
      <form onSubmit={handleSubmit}>
       <div className='form-field'>
        <label className='form-data'>Name</label>
        <input type="text" placeholder='name' onChange={handleChange}  name='name'  />
       </div>
       <br/>
       <br/>
       <div className='form-field'>
        <label className='form-data'>Age</label>
        <input type="number" placeholder='age'  name='age'  onChange={handleChange}  />
       </div>
       <br/>
       <br/>
       <div className='form-field'>
        <label className='form-data'>Gender</label>
        <input type="radio" onChange={handleChange} checked={formValues.gender=='male'}  value='male'  name='gender'  />Male
        <input type="radio" onChange={handleChange} checked={formValues.gender=='female'} value='female' name='gender'   />Female
        <input type="radio" onChange={handleChange} checked={formValues.gender=='others'} value='others' name='gender'    />Others
       </div>
       <br/>
       <br/>
       <div className='form-field'>
        <label className='form-data'>Occupation</label>
        <select onChange={handleChange} value={formValues.occupation} name='occupation'>
            <option>--select--</option>
            <option value='frontend' >Frontend</option>
            <option value='backend' >Backend</option>
            <option value='full-stack' >Full stack</option>
        </select>
       </div>
       <br/>
       <br/>
       <div className='form-field'>
        <label className='form-data'>are you cool ?</label>
        <input type="checkbox" onChange={handleChange} value={formValues.iscool} name="iscool"/> of course i am cool
       </div>
       <br/>
       <br/>
       <div className='form-field2'>
        <button>submit</button>
       </div>
      </form>
    </div>
    
  );
}
export default Form