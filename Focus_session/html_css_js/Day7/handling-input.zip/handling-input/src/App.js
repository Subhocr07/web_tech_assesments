import Form from './form';

function App() {
  return (
    <>
    <Form/>
    </>
  );
}

export default App;
