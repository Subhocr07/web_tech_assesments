const name=document.getElementById('name')
const form=document.getElementById('form')
const handleform=(event)=>{
    event.preventDefault()
    const username=document.getElementById('username').value
    const email=document.getElementById('email').value
    const password=document.getElementById('password').value
    const checkpassword=document.getElementById('check-password').value
    if(username==""){
        name.innerHTML="please enter name"
    }
    console.log(username);
    console.log(email);
    console.log(password);
    console.log(checkpassword)
}
form.addEventListener('submit',handleform)