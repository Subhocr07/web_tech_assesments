import React from "react";
import Shopping from "./component/shopping";

function App() {
  return (
    <>
    <Shopping/>
    </>
  );
}

export default App;
