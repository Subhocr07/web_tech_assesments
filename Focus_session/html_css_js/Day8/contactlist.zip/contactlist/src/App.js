import React,{useState,useEffect} from "react";
import Contact from "./component/contact";


function App() {
  const[contacts,setContacts]=useState([]);

  useEffect(()=>{
    fetch('https://randomuser.me/api/?results=6')
    .then(res=>res.json())
    .then(data=>{
        console.log(data)
        setContacts(data.results)
    })
},[])
  return (
    <>
      {
        contacts.map((contact)=>{
         return(
          <Contact 
          pictureUrl={contact.picture.large}
          name={contact.name.first}
          email={contact.email}
          age={contact.dob.age}
        />
         )
        })
      }
    </>
   
  );
}

export default App;
