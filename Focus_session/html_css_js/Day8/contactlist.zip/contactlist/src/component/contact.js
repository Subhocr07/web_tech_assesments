import React, { useState } from 'react'
import './contact.css'

const Contact = (props) => {
    const[age,setAge]=useState(false);
    

    const ToggleAge=()=>{
        setAge(!age)
    }
  return (
    <div className='card'>
    <img src={props.pictureUrl} alt="profile"></img>
    <div className='details'>
        <p>Name :{props.name} </p>
        <p>Email :{props.email} </p>
        <button onClick={()=>{ToggleAge()}}>Toggle Age</button>
        {age && <p>Age : {props.age}</p>}
    </div>
</div>
  )
}
export default Contact