import React from "react";
import Quiz from "./component/Quiz";

function App() {
  return (
    <>
    <Quiz/>
    </>
  );
}

export default App;
